from django.shortcuts import render
from .models import Gift 
from django.http import JsonResponse, HttpResponse
from django.core import serializers
from django.views.decorators.csrf import requires_csrf_token, ensure_csrf_cookie, csrf_exempt, csrf_protect
import random
from json import loads

@csrf_exempt
def main(request):
    if request.method == 'POST':
        idval = loads(request.body)['id']
        gifts = Gift.objects.order_by('?')
        context = serializers.serialize("json", gifts)
        present = Gift.objects.get(name = gifts[int(idval)].name)
        present.flag = True
        present.save()
        return JsonResponse(context, safe=False)
    else:
        context = {}
        return render(request, 'index.html', context)
