from django.conf import settings
from django.db import models
from django.utils import timezone
from easy_thumbnails.fields import ThumbnailerImageField
from django.contrib.auth.models import User


# class AdvUser(models.Model):
# 	is_activated = models.BooleanField(default=True)
# 	user = models.OneToOneField(User, on_delete=models.CASCADE)

# 	class Meta: 
# 		verbose_name_plural = 'Юзеры'
# 		verbose_name = 'Юзер'

class Gift(models.Model):

	name = models.CharField(max_length = 200, verbose_name='Название')
	image = ThumbnailerImageField(blank=True, null=True, resize_source={'size': (206, 206), 'crop': 'smart'}, verbose_name='Изображение')
	description = models.TextField(verbose_name='Описание')
	flag = models.BooleanField(default=False, verbose_name='Выйгрыш')
	user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='gifts')

	def __str__(self):
		return self.name

	class Meta: 
		verbose_name_plural = 'Подарки'
		verbose_name = 'Подарок'

class SetOfGifts(models.Model):

	name = models.CharField(max_length = 50, verbose_name = 'Название')
	gifts = models.ManyToManyField(Gift, related_name='sets')
	user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sets')

	def __str__(self):
		return self.name

	class Meta: 
		verbose_name_plural = 'Сеты'
		verbose_name = 'Сет'
