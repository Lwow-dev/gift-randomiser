from django.contrib import admin
from .models import Gift, SetOfGifts

class GiftAdmin(admin.ModelAdmin):
    list_display = ('name', 'user', 'description', 'flag',)
    list_display_links = ('name', 'description',)
    search_fields = ('name', 'description',)

# class AdvUserAdmin(admin.ModelAdmin):
#     list_display = ('user', 'gifts')


class SetOfGiftsAdmin(admin.ModelAdmin):
    list_display = ('name', 'user',)
    filter_horizontal = ('gifts',)

admin.site.register(Gift, GiftAdmin)
admin.site.register(SetOfGifts, SetOfGiftsAdmin)

# admin.site.register(AdvUser)
# Register your models here.
