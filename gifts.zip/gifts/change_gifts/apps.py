from django.apps import AppConfig


class ChangeGiftsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'change_gifts'
    verbose_name = 'Выбор подарков'
